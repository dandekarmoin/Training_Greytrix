--find out the list of the projects along with department name and number of asign employees

use examdb

select * from projects
select * from employees
select * from department
select * from assignments

select p.project_name, d.dept_name, count(e.emp_id) number_assign_employees
from employees e join projects p 
on e.dept_id = p.dept_id join department d
on d.dept_id = p.dept_id
group by d.dept_name, p.project_name


--find the employee who works maximum total hours in each department

select e.emp_name, dept_name, max(a.hours_worked) as max_total_hours
from assignments a join employees e
on a.emp_id = e.emp_id join department d
on e.dept_id = d.dept_id
group by dept_name, emp_name

insert into employees
values (106, 'sahil', 6, 78000, '2021-08-11')

insert into department
values(6, 'it')

insert into assignments
values(105, 206, 55)

sp_help assignments


--find out the departments that have the employees but no project assigned

select d.dept_name, e.emp_name, p.project_id
from employees e join department d
on d.dept_id = e.dept_id join projects p
on e.dept_id = p.dept_id
where p.project_id is  null


group by dept_name, p.project_id 
having p.project_id is not null