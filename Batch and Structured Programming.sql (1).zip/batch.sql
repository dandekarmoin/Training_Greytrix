--Set Operators

--union

select * from Emp
select * from Employee

select ename from Emp 
union
select vename from Employee

--union all

select ename from Emp 
union all
select vename from Employee


--intersect
select ename from Emp 
intersect
select vename from Employee

--except

select ename from Emp 
except
select vename from Employee


--Multiplication of 2 numbers

declare 
@n1 int,
@n2 int,
@res int
begin
set @n1=90
set @n2=89
set @res=@n1+@n2
print 'Multiplication is '+convert(varchar(20), @res)
end

--if--else

declare
@face int,
@pin int,
@finger int
begin
set @face=0
set @finger=1
set @pin=1

if @pin=0
print 'Mobile Unlocked using  PIN'
else if @face=0
print 'Mobile Unlocked using  Face recognization'
else if @finger=0
print 'Mobile Unlocked using  Fingerprint'
else
print 'Mobile Locked'
end


--

select * from Employee

declare 
@des varchar(20)
begin
set @des='Tester'
if @des='Develper'
begin
update Employee set salary=salary+2000 where design=@des
end
else if @des='Tester'
begin
update Employee set salary=salary+1000 where design=@des
end
else
print 'No updation'
end

select * from Employee

--case statements
declare 
@option varchar(20),
@output varchar(20)
begin
set @option='Latte'
set @output=
case @option
when 'Latte' then 'Selected Latte'
when 'Tea' then 'Selected Tea'
else
 'Please select '
end
print @output
end


--search case

select * from Employee

begin
select efname,design, case 
when salary>10000 and salary<15000 then 'Salary between 10000 and 15000'
when salary>=15000 and salary<=25000 then 'Salary between 15000 and 25000'

when salary>=25000 and salary<=35000 then 'Salary between 25000 and 35000'
else 'Invalid Salary' 
end  as Salary from Employee
end



--Looping
declare 
@num int=1,
@r int=0
begin
while  @num<=10
begin
set @r=@r+@num
set @num=@num+1
end
print 'Addition is '+convert(varchar(10),@r)
end

--continue and break

declare 
@n int=1
begin
while @n<=10
begin
print @n
set @n=@n+1
if @n>5
break
end
end

--continue

declare
@n4 int=0
begin
while @n4<=10
begin
set @n4=@n4+1
if @n4%2=0
continue
print @n4
end
end