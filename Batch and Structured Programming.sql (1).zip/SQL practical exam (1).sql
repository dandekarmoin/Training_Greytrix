create database examdb
use examdb

Database Schema
�	Employees(emp_id, emp_name, dept_id, salary, hire_date)
�	Departments(dept_id, dept_name)
�	Projects(project_id, project_name, dept_id)
�	Assignments(emp_id, project_id, hours_worked)

Note:-Insert 5 records in each table

--creates tavles
create table department
(
    dept_id int primary key,
    dept_name varchar(20)
)

create table employees
(
    emp_id int primary key,
    emp_name varchar(20),
    dept_id int,
    salary money,
    hire_date date,
    foreign key (dept_id) references department(dept_id)
)

create table projects
(
    project_id int primary key,
    project_name varchar(20),
    dept_id int,
    foreign key (dept_id) references department(dept_id)
)

create table assignments
(
    emp_id int,
    project_id int,
    hours_worked int,
    foreign key (emp_id) references employees(emp_id),
    foreign key (project_id) references projects(project_id)
)

insert into department (dept_id, dept_name) values
(1, 'hr'),
(2, 'it'),
(3, 'finance'),
(4, 'marketing'),
(5, 'sales');

insert into employees (emp_id, emp_name, dept_id, salary, hire_date) values
(101, 'amit', 2, 60000, '2022-01-10'),
(102, 'neha', 1, 45000, '2021-07-15'),
(103, 'rahul', 3, 70000, '2020-03-20'),
(104, 'priya', 4, 50000, '2023-06-01'),
(105, 'vijay', 5, 55000, '2022-11-25');

insert into projects (project_id, project_name, dept_id) values
(201, 'erp_system', 2),
(202, 'recruitment_drive', 1),
(203, 'budget_analysis', 3),
(204, 'brand_campaign', 4),
(205, 'sales_tracker', 5);

insert into assignments (emp_id, project_id, hours_worked) values
(101, 201, 40),
(102, 202, 35),
(103, 203, 45),
(104, 204, 30),
(105, 205, 50)

--ceck for record in tavles
select * from assignments
select * from employees
select * from projects
select * from department

--1.	Display department-wise total salary expenditure.
select d.dept_name, sum(e.salary) as total_salary
from employees e
join department d on e.dept_id = d.dept_id
group by d.dept_name

--2.	Find employees earning more than the average salary of their department.
select e.emp_id, e.emp_name, e.salary, e.dept_id
from employees e
where e.salary >
(
select avg(e2.salary)
from employees e2
   where e2.dept_id = e.dept_id
	)

--3.	List departments that have no projects assigned.
select d.dept_name, p.project_name
from projects p left join department d
on d.dept_id = p.dept_id
where p.project_id is null

--4.	Display employees who work on more than 2 projects.
select e.emp_id, e.emp_name
from employees e
join assignments a on e.emp_id = a.emp_id
group by e.emp_id, e.emp_name
having count(distinct a.project_id) > 2

--5.	Find the employee who worked the maximum total hours
select top 1 e.emp_id, e.emp_name, sum(a.hours_worked) as total_hours
from employees e
join assignments a on e.emp_id = a.emp_id
group by e.emp_id, e.emp_name
order by total_hours desc

--6.	Display department name and number of employees hired after 2020.
select d.dept_name, count(e.emp_id) as employee_count
from department d
join employees e on d.dept_id = e.dept_id
where (e.hire_date) > 2020
group by d.dept_name

--7.	List projects where no employee has worked more than 50 hours.
select p.project_id, p.project_name
from projects p
join assignments a on p.project_id = a.project_id
group by p.project_id, p.project_name
having max(a.hours_worked) <= 50

--8.	Find employees who earn the same salary as someone in another department.
select e1.emp_id, e1.emp_name, e1.salary
from employees e1
join employees e2
on e1.salary = e2.salary




--9.	Display the top 3 highest-paid employees in each department.
select top 3 
from
(  select           
  from employees 
)order by salary desc 

select top 3 empName , salary,count(*) from employees 
group by department
order by salary desc 


select * from employees



--10.	Create a view showing employee name, department name, and total hours worked.
create view vw_employee_hours as
select e.emp_name,
       d.dept_name,
       sum(a.hours_worked) as total_hours
from employees e
join department d on e.dept_id = d.dept_id
join assignments a on e.emp_id = a.emp_id
group by e.emp_name, d.dept_name

select * from vw_employee_hours








































