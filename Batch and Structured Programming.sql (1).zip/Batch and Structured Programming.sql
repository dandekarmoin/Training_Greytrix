Batch and Structured Programming
--1.	WAP to calculate are of triangle, rectangle and square
	declare 
	@base int = 6,
	@height int = 8,
	@areaTriangle float,
	@length int = 4,@breadth int =5,
	@areaRectangle int,
	@side int = 5,
	@areaSquare int
	begin
	set @areaTriangle = 0.5*@base*@height;
	set @areaRectangle=@length*@breadth;
	set @areaSquare = @side*@side;

	print'area of triangle is ' + convert(varchar(10) ,@areaTriangle)
	print 'area of rectabgle ' + convert(varchar(10),@areaRectangle)
	print'area of square is ' + convert(varchar(10),@areaSquare)
	
	end


--2.	WAP to calculate Simple Interest
declare
@principle int =100000 ,
@numYears int = 2,
@rateInterest int = 8,
@SI float 
begin 
set @SI = (@principle*@numYears*@rateInterest)/100;

print 'Simple Interest is ' + convert(varchar(10),@SI)
end

--3.	WAP to find cube of any number

declare
@num int = 3,
@cubeNum int
begin 
set @cubeNum = @num*@num*@num;
--or
-- set @cubeNum = power(@num,3)
print 'the cube of the number '+ convert(varchar(20),@num)+' is : '+convert(varchar(20),@cubeNum)

end

--4.	WAP to calculate percentage of 5 subjects
declare
@s1 int = 75,
@s2 int =80,
@s3 int = 82,
@s4 int = 81,
@s5 int =80,
@percentage float
begin 

set @percentage =convert(float, ((@s1+@s2+@s3+@s4+@s5)*100)/500);
print @percentage
end

--5.	WAP to find the details of saleman using batch

create table salesman (id int primary key,name varchar(100),city varchar(100),
commission money
);
insert into salesman values(1, 'raj', 'mumbai', 1050),(2, 'amit', 'delhi', 1200),
(3, 'neha', 'pune', 975),(4, 'sara', 'mumbai', 1125),
(5, 'vikas', 'bangalore', 850);



begin
select* from salesman;
end 
go

--6.	WAP to update the commission by 5% of any salesman 
begin 
update salesman set commission = commission + 0.05*commission
where name = 'raj';

end
select * from salesman



--7.	WAP to display Number is divisibly by 7 and 3

declare 
@num int = 1;
begin
while @num < 100
begin
if (@num % 7 = 0 AND @num % 3 = 0)
begin
print @num;
end

set @num = @num + 1;
end
end



--8.	WAP to display greatest number among 3 numbers
declare
@a int,
@b int,
@c int,
@max int

begin
set @a=10
set @b=20
set @c=30

set @max=@a

if @b>@max
set @max=@b

if @c>@max
set @max=@c

print 'greatest number is '+convert(varchar(20),@max)
end

--9.	WAP to display candidate info whose passout year between 2022-2024[Use Candidate]
create table candidates(candidateid int primary key,name varchar(50),graduation_year int);

insert into candidates values (1,'rahul',2022),(2,'amit',2023),(3,'neha',2024),
(4,'pooja',2021),(5,'vikas',2025);

select * from candidates

declare
@passYearStart int =2022,
@passYearEnd int =2024


begin
select * from candidates where graduation_year between @passYearStart and @passYearEnd
end


--10.	WAP to change Job Title of any Employee using JobId[use Job table]
create table jobs (jobid int primary key,job_title varchar(50),department varchar(50),desired_salary int);

insert into jobs values (1,'developer','it',25000),(2,'accountant','finance',35000),(3,'tester','qa',18000),
(4,'manager','hr',45000);

select * from jobs

declare 
@jId int =2
begin
if @jId = 2
begin 
update jobs set job_title ='Finance Analyst' where jobid = @jId
end
end

select * from jobs
--11.	WAP To display department using following conditons [use Job table]
Desired_salary	
10000-20000	
20001-30000
30001-40000
>40000


select *,
case
when desired_salary between 10000 and 20000 then 'qa'
when desired_salary between 20001 and 30000 then 'it'
when desired_salary between 30001 and 40000 then 'finance'
else 'management'
end as department
from jobs;

select * from job
--12.	WAP to display print number of days in a month using case

declare
@days int,
@month int = 2

set @days = case 
when @month in (1,3,5,7,8,10,12) then 31
when @month in (4,6,9,11) then 30
when @month = 2 then 28 

end
print @days

--13.	WAP to display Expected salary of candidate using Designation[use candidate table][with case]
create table candidate_detail(candidateid int primary key,
name varchar(50),designation varchar(30),highest_degree varchar(20),experience int);

insert into candidate_detail values(1,'rahul','developer','be',12),
(2,'amit','tester','bsc',6),(3,'neha','analyst','msc',7),
(4,'pooja','consultant','be',8),(5,'vikas','trainee','be',2);


select * from candidate_detail

declare 
@expectedSal int,
@designation varchar(20) = 'developer'
begin
set @expectedSal = case 
when @designation = 'developer' then 35000
when @designation = 'tester' then 30000
when @designation = 'analyst' then 28000
when @designation = 'engineer' then 39000
when @designation = 'consultant' then 29000
when @designation = 'trainee' then 22000

end;

print 'the expected salary is :' + convert (varchar(20) , @expectedSal)

end

--14.	WAP to display table of any number[while loop]

declare 
@n int = 2,
@i int =1,
@r int 
begin
while @i<=10
begin
set @r = @n*@i

print @r

set @i = @i+1
end

end 


--15.	WAP to display salary using highest degree and experience [use Candidate Table]
Highest degree	experience		Salary
BE					 >10		200000
BE					5-10		150000
Msc					>5			100000
Bsc					5-10		90000
select *,
case
when highest_degree='be' and experience>10 then 200000
when highest_degree='be' and experience between 5 and 10 then 150000
when highest_degree='msc' and experience>5 then 100000
when highest_degree='bsc' and experience between 5 and 10 then 90000
end as salary
from candidate_detail;

select * from candidate_detail
--16.	WAP to check number is palindrome or not[loop]
declare
@num int = 121,
@temp int,
@rem int,
@rev int = 0;

set @temp = @num;

while (@temp > 0)
begin
set @rem = @temp % 10;
set @rev = (@rev * 10) + @rem;
set @temp = @temp / 10;
end

if (@num = @rev)
print 'number is palindrome';
else
print 'number is not palindrome';

--17.	WAP to find factorial of any number

declare
@num int = 5,
@fact bigint = 1,
@i int =1;
while (@i <=@num)
begin
set @fact = @fact*@i;
set @i=@i+1

end

print ('the factorial of this number is :' + convert(varchar(20),@fact))

--18.	WAP print all even numbers from 1 to 100

declare
@number int = 1
begin
print 'even numbers from 1 to 100 are : '

while @number <=100
begin
if (@number % 2=0)

print @number
set @number = @number +1
end

end
--19.	WAP to display prime numbers between 1 to 20 
declare
@num int = 2,
@i int;

while (@num <= 20)
begin
set @i = 2;
while (@i < @num and @num % @i <> 0)
begin
set @i = @i + 1;
end
if (@i = @num)
print convert( varchar(5),@num);
set @num = @num + 1;
end

--20.	WAP to display factors of 98 

declare
@num int = 98,
@i int = 1;

print 'factors of 98 are:'

while (@i <= @num)
begin
if (@num % @i = 0)
print convert( varchar(5),@i);

set @i = @i + 1;
end