use Tebisco
SELECT  @@SERVERNAME  as 'Server Name'

SELECT  @@VERSION  as 'SQL Server Version'

SELECT  @@Total_ERRORS  as 'number of disk read-write errors'

Select @@SERVICENAME as 'ServiceName'

SELECT * FROM Employee
SELECT @@rowcount as 'Count Number of Rows affected'

SELECT @@LANGUAGE as 'Language' 

select @@CPU_BUSY  as 'Busy milliseconds Time'

select @@IDLE as 'idle milliseconds Time'

-- identity value

     
     create table #demo(id int identity(1,1),name char(10)) 
     drop table #demo
     insert into #DEMO VALUES('Ram'),('Sita'),('Pooja'),('Raja')
     Select @@IDENTITY as identityvalue   -- 4
	select * from #demo	

SELECT * From  Employee
if(@@ERROR <> 0)
print 'Error Found'
else
print 'Error not Found'

select @@CONNECTIONS as 'Number of Login Attempts'
